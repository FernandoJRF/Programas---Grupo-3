
#Añadir texto
#anexar (‘a’): Este modo permite abrir el archivo para anexar información al final.
with open('Bosque_encantado.txt', 'a') as file: 
    file.write("Con el tiempo, el bosque se lleno de vida, y los arboles susurraban de felicidad.")
    file.write("\n\nClara se convirtio en la nueva guardiana del bosque, y su nombre se hizo conocido en todo el reino.")
    file.write("\nLos aldeanos, agradecidos, celebraban el respeto y la paz que florecieron en el lugar.")
    file.write("\n\nFin.")

